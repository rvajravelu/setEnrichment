library(MCEA)
library(msm)
library(reshape2)
library(ggplot2)
library(readr)
library(haven)
library(plyr)
library(dplyr)

table <- read.csv("crhcExampleForMcea.csv")

MCEA_routine_bootstrapped(table = table, numNullReps = numNullReps, standardize = TRUE, parameter = parameter, logTransformOR = TRUE, plotSomeWalks = TRUE)
