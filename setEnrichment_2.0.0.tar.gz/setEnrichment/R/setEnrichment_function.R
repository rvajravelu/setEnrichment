#' Apply set enrichment to a table of results from an xWAS study
#'
#' @param table DATA FRAME: Results from an xWAS study. Order of columns should be observation, set, and association.
#' @param parameter FLOAT: the tuning parameter for weighted steps; defaults to 1
#' @param logTransformAssoc BOOLEAN: if TRUE, weighted steps are 'ln(association)' instead of 'association'; appropriate for risk ratios, odds ratios, hazard ratios; default is TRUE
#' @param numClassesToPlot INTEGER: number of walks to plot; ties broken by lowest FDR, then highest absolute value of ES; defaults to 0
#' @param numNullReps INTEGER: number of random walks to generate the null distribution of enrichment score for each class; defaults to 1000
#' @param bootstrapCycles INTEGER: number of cycles for bootstrapping; defaults to 1000
#' @param seed INTEGER: seed for random number generation; set for reproducible results; defaults to 654321
#' @return enrichedResults: A DATA FRAME with the enrichment score of each set and parameters describing statistican significance (95% CIs from bootstrapping, p-value, Bonferroni-corrected p-value, and FDR)
#' @return walksPlot: A GGPLOT object if plotting options are selected
#' @export



setEnrichment <- function(table, parameter, logTransformAssoc, numClassesToPlot, numNullReps, bootstrapCycles, seed) {

  startTime <- Sys.time()


  # variable declarations and options

    # old inputs removed in v2

      Mootha <- FALSE # if TRUE, steps are increments from Mootha et al Nature Genetics 2003. If FALSE, steps weighted like Subramanian et al. PNAS 2005.
      bootstrapSamplePercentage <- 1 # percentage of observations to sample for each bootstrap
      bootstrapReplacement <- TRUE # whether to sample with replacement for bootstrapping

    obsTable <- table
    colnames(obsTable) <- c("obs", "class", "assoc")
    obsTable$className <- obsTable$class
    obsTable$class <- as.numeric(as.factor(obsTable$class))
    classDictionary <- unique(obsTable[,c(2,4)])
    classDictionary$className <- as.character(classDictionary$className)
    obsTable[obsTable$assoc == 0,"assoc"] <- 0.00000001


    # set defaults for non-specified inputs

      if (missing(parameter)) {
        parameter <- 1
      }

      if (missing(logTransformAssoc)) {
        logTransformAssoc <- FALSE
      }

      if (missing(numClassesToPlot)) {
        numClassesToPlot <- 0
      }

      if (numClassesToPlot < 0) {
        numcClassesToPlot <- 0
      }

      if (missing(numNullReps)) {
        numNullReps <- 1000
      }

      if (missing(bootstrapCycles)) {
        bootstrapCycles <- 1000
      }

      if (missing(seed)) {
        seed <- 654321
      }


  # data frame initialization

    set.seed(seed)
    numObs <- nrow(obsTable)
    obsList <- unique(obsTable$obs)
    numClasses <- length(unique(obsTable$class))
    classList <- unique(obsTable$class)

    bootstrapSample <- ceiling(bootstrapSamplePercentage * numObs)

    ES_DF <- data.frame(matrix(nrow = numClasses, ncol = 1)) # data frame that will store the ES's for each class
    rownames(ES_DF) <- classList
    colnames(ES_DF) <- "ES"

    randWalkDF <- data.frame(matrix(nrow = numObs, ncol = numClasses)) # data frame that will store the random walks used to calculate each ES for each class
    colnames(randWalkDF) <- classList
    rownames(randWalkDF) <- obsList

    p_valueDF <- data.frame(matrix(nrow = numClasses, ncol = 1)) # data frame to store p-values
    rownames(p_valueDF) <- classList
    colnames(p_valueDF) <- "p-value"


  # sort function

    sortObsTable <- function(obs){
      sortOrder <- order(obs$assoc, decreasing = TRUE)
      orderedObs <- obs[sortOrder, ]
    }


  # random walk function

    randomWalk <- function(obs, class) {

      walkPath <- data.frame(matrix(nrow = numObs, ncol = 1))
      if (!Mootha) {

        if (logTransformAssoc) {
          obs$assoc <- log(obs$assoc)
        }

        totalHitWeight <- sum(abs(obs[which(obs[ ,"class"] == class),"assoc"])^parameter)
        totalMisses <- sum(obs$class != class)
        obs$class[obs$class != class] <- 0
        obs$class[obs$class == class] <- 1
        walkWeights <- obs$class * (abs(obs$assoc)^parameter)/totalHitWeight
        walkWeights[which(walkWeights == 0)] <- -(1/totalMisses)
        walkPath <- cumsum(walkWeights)

      }

      else {
        totalHits <- sum(obs$class == class)
        totalMisses <- sum(obs$class != class)
        obs$class[obs$class != class] <- 0
        obs$class[obs$class == class] <- 1
        walkWeights[which(walkWeights == 0)] <- sqrt(totalMisses/totalHits)
        walkWeights[which(walkWeights == 0)] <- -sqrt(totalHits/totalMisses)
        walkPath <- cumsum(walkWeights)

      }

      return(walkPath)
    }


  # calculate enrichment score

    ESassign <- function(DF, class) {
      if (abs(max(DF[ ,class], na.rm = TRUE)) > abs(min(DF[ ,class], na.rm = TRUE))) {
        return(max(DF[ ,class], na.rm = TRUE))
      }
      else {
        return(min(DF[ ,class], na.rm = TRUE))
      }
    }


  # reassign class labels for null distribution calculation and call random walk to generate null distribution of ES

    generateNull <- function() {

      for (num in 1:numNullReps) {

        nullObsTable <- obsTable
        nullObsTable$class <- sample(x = nullObsTable$class, size = numObs)
        nullObsTable <- sortObsTable(nullObsTable)

        nullWalkDF <- data.frame(matrix(nrow = numObs, ncol = numClasses)) # data frame used to calculate ES
        colnames(nullWalkDF) <- classList
        rownames(nullWalkDF) <- as.character(obsList)

        for (i in classList) {
          nullWalkDF[ ,as.character(i)] <- randomWalk(nullObsTable, as.character(i))
          nullES_DF[num,as.character(i)] <- ESassign(DF = nullWalkDF, class = as.character(i))
        }

      }
      return(nullES_DF)
    }


  # permutation method to calculate p-values

    calc_p_permute <- function() {
      p_value_permuteDF <- data.frame(matrix(nrow = numClasses, ncol = 4))
      colnames(p_value_permuteDF) <- c("ES", "greater", "less", "p_value")
      rownames(p_value_permuteDF) <- classList
      for (i in classList) {
        p_value_permuteDF[as.character(i),"ES"] <- standardES_DF[as.character(i),"ES_std"]
        p_value_permuteDF[as.character(i),"greater"] <- sum(standardNull_ES_DF[ ,as.character(i)] <= p_value_permuteDF[as.character(i), "ES"])
        p_value_permuteDF[as.character(i),"less"] <- sum(standardNull_ES_DF[ ,as.character(i)] >= p_value_permuteDF[as.character(i), "ES"])
        p_valueDF[as.character(i),1] <- min(p_value_permuteDF[as.character(i), "greater"]/numNullReps, p_value_permuteDF[as.character(i), "less"]/numNullReps, 0.5) * 2
      }

      return(p_valueDF)

    }


  # standardize enrichment score and null distribution of enrichment scores

    standardizeES <- function() {
      stdevES_DF <- data.frame(matrix(nrow = numClasses, ncol = 4))
      rownames(stdevES_DF) <- classList
      colnames(stdevES_DF) <- c("class", "ES", "nullES_SD", "ES_std")
      stdevES_DF$class <- classList
      stdevES_DF$ES <- ES_DF$ES
      for (i in classList) {
        stdevES_DF[as.character(i),"nullES_SD"] <- stats::sd(nullES_DF[ ,as.character(i)])
      }
      stdevES_DF$ES_std <- stdevES_DF$ES/stdevES_DF$nullES_SD
      return(stdevES_DF)
    }

    standardizeNull <- function(standardES_DF) {
      nullES_DF_std <- nullES_DF
      for (i in classList) {
        nullES_DF_std[,as.character(i)] <- nullES_DF_std[,as.character(i)]/standardES_DF[as.character(i), "nullES_SD"]
      }
      return(nullES_DF_std)
    }


  # graph the walk of select classes

    graphSomeWalks <- function(classList) {
      randWalkDF$position <- 1:numObs
      meltWalkDF <- reshape2::melt(randWalkDF, id.vars = "position")
      colnames(meltWalkDF) <- c("position", "class", "excursion")
      meltWalkDF <- merge(meltWalkDF, classDictionary, by = "class")
      meltWalkDF <- meltWalkDF[meltWalkDF$class %in% classList, ]
      lineGraph <- ggplot2::ggplot(data = meltWalkDF) +
                   ggplot2::aes(x=position, y=excursion, group=className) +
                   ggplot2::geom_line(ggplot2::aes(color = className)) +
                   ggplot2::theme(axis.text.x = ggplot2::element_blank(), axis.ticks = ggplot2::element_blank(), axis.title.x = ggplot2::element_blank(), legend.title = ggplot2::element_blank()) +
                   ggplot2::ggtitle("Random walk by class") +
                   ggplot2::scale_colour_discrete(breaks = classDictionary$className) +
                   ggplot2::theme(plot.title = ggplot2::element_text(size = 18)) +
                   ggplot2::theme(axis.title = ggplot2::element_text(size = 18)) +
                   ggplot2::theme(axis.text = ggplot2::element_text(size = 18)) +
                   ggplot2::theme(legend.text = ggplot2::element_text(size = 18))
      return(lineGraph)
    }


  # bootstrapping function to estimate 95% confidence intervals

    bootstrapES <- function() {

      resultTableTemp <- p_valueDF[order(p_valueDF$class),]

      finalBootstrapES_DF <- data.frame(matrix(nrow = numClasses, ncol = bootstrapCycles))
      rownames(finalBootstrapES_DF) = classList

      bootstrapSummaryTable <- data.frame(matrix(nrow = numClasses, ncol = 6))
      colnames(bootstrapSummaryTable) <- c("class", "ES", "bootstrap_n", "bootstrap_ES_SE", "95CI_low", "95CI_high")

      for (cycle in 1:bootstrapCycles) {

        bootstrapES_DF <- data.frame(matrix(nrow = numClasses, ncol = 1)) # data frame that will store the ES's for each class
        rownames(bootstrapES_DF) <- classList
        colnames(bootstrapES_DF) <- "ES"

        bootstrapRandWalkDF <- data.frame(matrix(nrow = numObs, ncol = numClasses)) # data frame that will store the random walks used to calculate each ES for each class
        colnames(bootstrapRandWalkDF) <- classList

        bootstrapObs <- obsTable[sample(nrow(obsTable), size = bootstrapSample, replace = bootstrapReplacement),]
        bootstrapObs <- sortObsTable(bootstrapObs)
        bootstrapClassList <- unique(bootstrapObs$class)

        for (j in bootstrapClassList) {
          bootstrapRandWalkDF[1:bootstrapSample ,as.character(j)] <- randomWalk(obs = bootstrapObs, as.character(j))
          bootstrapES_DF[as.character(j),"ES"] <- ESassign(DF = bootstrapRandWalkDF, class = as.character(j))
        }

        for (k in classList) {
          finalBootstrapES_DF[as.character(k),cycle] <- bootstrapES_DF[as.character(k),"ES"]
        }

      }

      bootstrapSummaryTable[,"class"] <- classList
      bootstrapSummaryTable[,"ES"] <- resultTableTemp[,"ES"]
      bootstrapSummaryTable[,"bootstrap_n"] <- bootstrapCycles - rowSums(is.na(finalBootstrapES_DF[,]))
      bootstrapSummaryTable[,"bootstrap_ES_SE"] <- apply(finalBootstrapES_DF,1,stats::sd,na.rm = TRUE)/sqrt(bootstrapSummaryTable[,"bootstrap_n"])
      bootstrapSummaryTable[,"95CI_low"] <- bootstrapSummaryTable[,"ES"] - 1.98*bootstrapSummaryTable[,"bootstrap_ES_SE"]
      bootstrapSummaryTable[,"95CI_high"] <- bootstrapSummaryTable[,"ES"] + 1.98*bootstrapSummaryTable[,"bootstrap_ES_SE"]

      return(bootstrapSummaryTable)

    }


  # Calculate run time

    printRunTime <- function(t){
      paste("Total run time (D HH:MM:SS)  "
        ,t %/% (60*60*24)
            ,paste(formatC(t %/% (60*60) %% 24, width = 2, format = "d", flag = "0")
                   ,formatC(t %/% 60 %% 60, width = 2, format = "d", flag = "0")
                   ,formatC(t %% 60, width = 2, format = "d", flag = "0")
                   ,sep = ":"
            )
      )
    }



######### PROGRAM STARTS BELOW   #########



  obsTable <- sortObsTable(obsTable)

  for (index in classList) {
    randWalkDF[ ,as.character(index)] <- randomWalk(obs = obsTable, as.character(index))
    ES_DF[as.character(index), ] <- ESassign(DF = randWalkDF, class = as.character(index))
  }

  nullObsTable <- data.frame(matrix(nrow = numObs, ncol = ncol(obsTable))) # data frame to store the randomly generated OR list to generate null distribution of ES
  colnames(nullObsTable) <- colnames(obsTable)
  nullObsTable$obs <- obsTable$obs
  nullObsTable$class <- obsTable$class
  nullES_DF <- data.frame(matrix(nrow = numNullReps, ncol = numClasses)) # data frame to store the null ES distribution for each class
  colnames(nullES_DF) <- classList
  nullES_DF <- generateNull()

  standardES_DF <- standardizeES()
  standardNull_ES_DF <- standardizeNull(standardES_DF)

  p_valueDF <- calc_p_permute()
  colnames(p_valueDF) <- "p_value"
  p_valueDF$class <- classList
  p_valueDF$ES <- ES_DF[ ,1]
  p_valueDF <- p_valueDF[,c(2,3,1)]
  sort_p_Order <- order(p_valueDF$p_value, decreasing = FALSE)
  p_valueDF <- p_valueDF[sort_p_Order, ]


# Bonferroni correction
  p_valueDF$Bonferroni <- pmin(p_valueDF$p_value * numClasses, 1)


# qi calculation for FDR

  sortedClassList <- p_valueDF$class
  num_p_valueClasses <- length(sortedClassList)
  lastSortedClass <- sortedClassList[num_p_valueClasses]

  for (row in 1:num_p_valueClasses) {
    p_valueDF[row,"qi"] <- min(((numClasses*p_valueDF[as.numeric(row),"p_value"]))/row,1, na.rm = TRUE)
  }


# FDR calculation

  for (row2 in 1:num_p_valueClasses) {
    p_valueDF[row2,"FDR"] <- min(p_valueDF[as.numeric(row2):num_p_valueClasses,"qi"], na.rm = TRUE)
  }


# call bootstrapping function

  ES_bootstrapped <- bootstrapES()


# process table of results

  resultsTable <- merge(p_valueDF, ES_bootstrapped, by = "class")
  resultsTable <- resultsTable[, c(1,2,3,10,11,4,5,6)]
  names(resultsTable)[names(resultsTable) == "ES.x"] <- "ES"
  resultsTable <- merge(resultsTable, classDictionary, by = "class")
  resultsTable$absES <- abs(resultsTable$ES)
  resultsTable <- resultsTable[order(resultsTable$FDR, -resultsTable$absES),]
  resultsTable <- resultsTable[, c(1,9,2,3,4,5,6,7,8)]
  assign("enrichedResults", resultsTable, envir = globalenv())


# plot walks

  if (numClassesToPlot > 0) {
    numClassesToPlot <- floor(min(numClassesToPlot, numObs))
    graphClasses <- resultsTable$class[1:numClassesToPlot]
    someWalks <- graphSomeWalks(graphClasses)
    print(someWalks)
    assign("walksPlot", someWalks, envir = globalenv())
  }


# return table of results to global environment

  resultsTable <- resultsTable[, c(2,3,4,5,6,7,8,9)]
  names(resultsTable)[names(resultsTable) == "className"] <- "set"
  assign("enrichedResults", resultsTable, envir = globalenv())

# print run time

  printRunTime(as.numeric(Sys.time()-startTime))

}
